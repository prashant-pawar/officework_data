<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Question_master extends CI_Controller {

	public function index()
	{
		$this->load->view('questions_view');
	}

	//This Method is used for Add Record
	public function add_record()
	{
		$posted_data=$this->input->post();
			/*This Condition used for Update*/
		if (!empty($posted_data['question_id'])) {
				$id['question_id']=$posted_data['question_id'];
			$this->Custom_model->updateRow('questions_master',$posted_data,$id);
			echo json_encode(true);
		}
		else {
			
			$this->Custom_model->insertRow('questions_master',$posted_data);
			echo json_encode(true);
		}
	}

	//This function Used For Show Record
	public function show_data()
	{
		$data=$this->Custom_model->getRows('questions_master');
		echo json_encode($data);
	}

	public function edit_record()
	{
		$id=$this->input->post();
		$data=$this->Custom_model->getSingleRow('questions_master',$id);
		echo json_encode($data);
	}

	public function delete_record()
	{
		$id=$this->input->post();
		$data=$this->Custom_model->deleteRow('questions_master',$id);
		echo json_encode(true);

	}


	public function datatable_rd()
	{

		$database_data=$this->Custom_model->getRows('questions_master');
		echo json_encode($data);
		
        $draw = intval($this->input->post("draw"));
        $start = intval($this->input->post("start"));
        $length = intval($this->input->post("length"));
        $order = $this->input->post("order");
        $search= $this->input->post("search");
        $search = $search['value'];
        $col = 0;
        $dir = "";

         if(!empty($order))
        {
            foreach($order as $o)
            {
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }

        if($dir != "asc" && $dir != "desc")
        {
            $dir = "desc";
        }
        $valid_columns = array(
            0=>'question_id',
            1=>'question',
            2=>'opt_1',
            3=>'opt_2',
            4=>'opt_3',
            5=>'opt_4',
            6=>'true_ans',
        );
        if(!isset($valid_columns[$col]))
        {
            $order = null;
        }
        else
        {
            $order = $valid_columns[$col];
        }
        if($order !=null)
        {
            $this->db->order_by($order, $dir);
        }
        
        if(!empty($search))
        {
            $x=0;
            foreach($valid_columns as $sterm)
            {
                if($x==0)
                {
                    $this->db->like($sterm,$search);
                }
                else
                {
                    $this->db->or_like($sterm,$search);
                }
                $x++;
            }                 
        }
        $this->db->limit($length,$start);
        $table_qm = $this->db->get("questions_master");
        $data = array();
        foreach($table_qm->result() as $rows)
        {

            $data[]= array(
                $rows->question_id,
                $rows->question,
                $rows->opt_1,
                $rows->opt_2,
                $rows->opt_3,
                $rows->opt_4,
                $rows->true_ans,
                '<a href="#" class="btn btn-warning mr-1">Edit</a>
                 <a href="#" class="btn btn-danger mr-1">Delete</a>'
            );     
        }
        $total_record = $this->totalrecord();
        $output = array(
            "draw" => $draw,
            "recordsTotal" => $totalrecord,
            "recordsFiltered" => $totalrecord,
            "data" => $data
        );
        echo json_encode($output);
        exit();
    }
    public function totalrecord()
    {
        $query = $this->db->select("COUNT(*) as num")->get("questions_master");
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }
}

	


/* End of file Question_master.php */
/* Location: ./application/controllers/Question_master.php */