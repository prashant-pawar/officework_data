<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Question_master_model extends CI_Model {

	public function add_record($table,$data)
	{
		$this->db->insert($table,$data);

	}

	public function show_data($table)
	{
		$query=$this->db->get($table);
		return $query->result();

	}

	public function edit_data($table,$id)
	{
		$query=$this->db->get_where($table,$id);
		return $query->row();
	}

	public function update_record($table,$id,$data)
	{
		$this->db->update($table,$id,$data);
	}

	public function delete_data($table,$id)
	{
		$this->db->delete($table,$id);
	}

}

/* End of file Question_master_model.php */
/* Location: ./application/models/Question_master_model.php */