<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	public function index()
	{
		$this->load->view('crud_view');
	}

	public function fatch_user()
	{
		$this->load->model("crud_model");
		$fetch_data=$this->crud_model->make_datatables();
		$data=array();

		foreach ($fetch_data as $row) {
			$sub_array =array();
			$sub_array[]=$row->name;
			$sub_array[]=$row->username;
			$data[]	=$sub_array;
		}
		$output =array(
			"draw" => intval($_POST["draw"]),
			"recordsTotal" =>$this->crud_model->get_all_data(),
			"recordsFiltered" =>$this->crud_model->get_filtered_data(),
			"data"=> $data
		);
		echo json_encode($output);
	}

}

/* End of file Crud.php */
/* Location: ./application/controllers/Crud.php */