<!DOCTYPE html>
<html>
<head>
	<title>Crud Operation using Datatable</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>

<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css"/>
<script type="text/javascript" src="//cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

</head>
<body>
	<table id="tbl" class="table table-bordered">
		<thead>
			<tr>
				<th>id</th>
				<th>Name</th>
				<th>Username</th>
				<th>Password</th>
			</tr>
		</thead>
	</table>
	<script >
		$(document).ready(function() {
			var datatable=$('#tbl').DataTable({
				"processing":true,
				"serverSide":true,
				"order":[],
				"ajax":{
					url:"<?php echo site_url('crud/fatch_user'); ?>",
					type:'POST'
				},
				"columnDef":[
					{
						"targets":[0,3,4],
						"orderable":false,
					}
				]
			});
		});
	</script>
</body>
</html>